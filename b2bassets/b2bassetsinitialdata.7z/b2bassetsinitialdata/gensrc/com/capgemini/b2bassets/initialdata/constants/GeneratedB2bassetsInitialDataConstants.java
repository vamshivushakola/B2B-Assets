/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jun 9, 2016 4:12:53 PM                      ---
 * ----------------------------------------------------------------
 */
package com.capgemini.b2bassets.initialdata.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedB2bassetsInitialDataConstants
{
	public static final String EXTENSIONNAME = "b2bassetsinitialdata";
	
	protected GeneratedB2bassetsInitialDataConstants()
	{
		// private constructor
	}
	
	
}
